/* Copyright 2020 The TensorFlow Authors. All Rights Reserved.

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
==============================================================================*/

#ifndef TENSORFLOW_LITE_MICRO_KERNELS_CIRCULAR_BUFFER_H_
#define TENSORFLOW_LITE_MICRO_KERNELS_CIRCULAR_BUFFER_H_

#include "tensorflow/lite/micro/builtin_op_data.h"
#include "tensorflow/lite/micro/micro_common.h"

namespace tflite {
namespace micro {
// The CircularBuffer op has one input and up to two output tensors.
// - Output 0: buffered history tensor (variable tensor).
// - Output 1 (optional): boolean scalar tensor indicating whether the buffer
//   period has elapsed and new outputs are valid.
extern const int kCircularBufferInputTensor;
extern const int kCircularBufferOutputTensor;
extern const int kCircularBufferValidOutputTensor;

// Indices into the init flexbuffer's vector.
// The parameter's name is in the comment that follows.
// Elements in the vectors are ordered alphabetically by parameter name.
extern const int kCircularBufferCyclesMaxIndex;  // 'cycles_max'

// These fields control the stride period of a strided streaming model.
// For single-output models, this op returns kTfLiteAbort until
// cycles_until_run-- reaches zero. For dual-output models, readiness is
// written to the valid output tensor and kTfLiteOk is returned.
// In both cases, cycles_until_run is reset to cycles_max when ready.
struct OpDataCircularBuffer {
  int cycles_until_run;
  int cycles_max;
};

TfLiteStatus CircularBufferPrepare(TfLiteContext* context, TfLiteNode* node);

}  // namespace micro
using micro::OpDataCircularBuffer;
}  // namespace tflite

#endif  // TENSORFLOW_LITE_MICRO_KERNELS_CIRCULAR_BUFFER_H_
