#!/bin/sh
# Copyright 2019 The TensorFlow Authors. All Rights Reserved.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
# ==============================================================================

DOCKER_FLAG=""
if [ "${TFLM_PRE_PUSH_DOCKER:-0}" = "1" ] || [ "${USE_DOCKER:-0}" = "1" ]; then
  DOCKER_FLAG="--docker"
fi

tensorflow/lite/micro/tools/ci_build/test_code_style.sh ${DOCKER_FLAG}
