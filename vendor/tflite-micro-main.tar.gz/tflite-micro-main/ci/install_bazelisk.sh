#!/usr/bin/env bash
# Copyright 2021 The TensorFlow Authors. All Rights Reserved.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
# ==============================================================================

set -e
export BAZELISK_HOME="${BAZELISK_HOME:-/opt/bazelisk}"
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
VERSION_FILE="${SCRIPT_DIR}/.bazelversion"
[ -f "${VERSION_FILE}" ] || VERSION_FILE="${SCRIPT_DIR}/../.bazelversion"
wget -qO /usr/local/bin/bazel https://github.com/bazelbuild/bazelisk/releases/download/v1.29.0/bazelisk-linux-amd64
chmod +x /usr/local/bin/bazel
USE_BAZEL_VERSION="$(tr -d '[:space:]' < "${VERSION_FILE}")" /usr/local/bin/bazel --version
chmod -R a+rwX "${BAZELISK_HOME}"
